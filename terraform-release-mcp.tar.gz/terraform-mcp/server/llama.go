package main

/*func Ask(prompt string) (string, error) {
	payload := map[string]string{"prompt": prompt}
	data, _ := json.Marshal(payload)

	resp, err := http.Post("http://localhost:8080/ask", "application/json", bytes.NewBuffer(data))
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, _ := ioutil.ReadAll(resp.Body)

	var result map[string]string
	json.Unmarshal(body, &result)

	return result["response"], nil
} */

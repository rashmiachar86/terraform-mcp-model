package main

import (
	"context"
	"fmt"
	"log"
	"time"

	//	"google.golang.org/grpc"

	pb "terraform-mcp/mcp"

	"google.golang.org/grpc"
)

func main() {
	conn, err := grpc.Dial("localhost:9090", grpc.WithInsecure())
	if err != nil {
		log.Fatal(err)
	}
	defer conn.Close()

	client := pb.NewReleaseServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*100)
	defer cancel()

	resp, err := client.GetReleases(ctx, &pb.ReleaseRequest{})
	if err != nil {
		log.Fatalf("Error calling GetReleases: %v", err)
	}

	// Print the results
	fmt.Println("Terraform Enterprise 2024 Releases:")
	for _, release := range resp.Releases {
		fmt.Printf("- Version: %s\n  CLI version: %s\n  URL: %s\n\n", release.Version, release.Date, release.Url)
	}

	//new ones added
	latest, err := client.GetLatestRelease(ctx, &pb.Empty{})
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Latest Release: %s (%s)\n", latest.Version, latest.Url)

	// Get Highlights
	/*highlights, err := client.GetHighlights(ctx, &pb.VersionRequest{Version: latest.versionno})

	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Highlights for %s:\n", latest.Version)
	for _, note := range highlights.Notes {
		fmt.Println("-", note)
	}
	*/
}

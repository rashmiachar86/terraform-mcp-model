package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net"
	"regexp"
	"strings"

	"net/http"

	"github.com/PuerkitoBio/goquery"
	"google.golang.org/grpc"

	pb "terraform-mcp/mcp"
)

type server struct {
	pb.UnimplementedReleaseServiceServer
}

type HFRequest struct {
	Inputs    string `json:"inputs"`
	MinLength int    `json:"min_length"`
	MaxLength int    `json:"max_length"`
}

type HFResponse []struct {
	SummaryText string `json:"summary_text"`
}

func (s *server) GetReleases(ctx context.Context, req *pb.ReleaseRequest) (*pb.ReleaseListResponse, error) {

	doc, err := http.Get("http://developer.hashicorp.com/terraform/enterprise/releases/2024")
	if err != nil {
		return nil, err
	}

	defer doc.Body.Close()
	if doc.StatusCode != 200 {
		return nil, fmt.Errorf("failed to fetch the URL: %s", doc.Status)
	}

	// Parse the HTML document
	parsedDoc, err := goquery.NewDocumentFromReader(doc.Body)
	if err != nil {
		return nil, err
	}

	var releases []*pb.Release

	versionTable := parsedDoc.Find((".mdx-table_root__adKqa"))

	// Looping through the table rows and extracting the version and date
	versionTable.Find("tbody tr").Each(func(i int, sel *goquery.Selection) {
		version := sel.Find("td").Eq(0).Text()
		date := sel.Find("td").Eq(1).Text()
		link, _ := sel.Find("a").Attr("href")
		//	fmt.Printf("- Version: %s\n  Date: %s\n  URL: %s\n\n", version, date)
		// Append the release information to the releases slice
		releases = append(releases, &pb.Release{
			Version: version,
			Date:    date,
			Url:     "http://developer.hashicorp.com" + link,
		})
	})

	return &pb.ReleaseListResponse{Releases: releases}, nil
}

func (s *server) GetLatestRelease(ctx context.Context, _ *pb.Empty) (*pb.Release, error) {
	doc, err := goquery.NewDocument("https://developer.hashicorp.com/terraform/enterprise/releases/2024")
	if err != nil {
		return nil, err
	}
	latest := doc.Find(".mdx-table_root__adKqa").First()
	//	fmt.Printf("- Version: %s", latest.Text())
	version := strings.TrimSpace(latest.Find("Version").Text())
	date := strings.TrimSpace(latest.Find("Version").First().Text())

	re := regexp.MustCompile(`v\d{6}-\d+`)
	version = re.FindString(latest.Text()) // Assign the result to the existing variable 'version'
	if version != "" {
		//	fmt.Println("\n First Version:", version)
		// Extract date part (e.g., from v202411-2 → 2024-11)
		year := version[1:5]
		month := version[5:7]
		date := year + "-" + month
		fmt.Printf("Date: %s-%s\n", date)
	}

	return &pb.Release{Version: version, Date: date}, nil
}

func (s *server) GetHighlights(ctx context.Context, req *pb.VersionRequest) (*pb.Highlights, error) {
	doc, err := goquery.NewDocument("https://developer.hashicorp.com/terraform/enterprise/releases/2024")
	if err != nil {
		return nil, err
	}
	var notes []string
	doc.Find("docs-view_mdxContent___uMnx").Each(func(i int, sel *goquery.Selection) {
		if strings.Contains(sel.Find("h3").Text(), req.Versionno) {
			sel.Find("ul li").Each(func(i int, li *goquery.Selection) {
				notes = append(notes, strings.TrimSpace(li.Text()))
			})
		}
	})
	return &pb.Highlights{Version: req.Versionno, Notes: notes}, nil
}

// new ones added

func startHTTPServer() {
	http.HandleFunc("/ask-llama", askLlamaHandler)
	log.Println("HTTP API running on :8081")
	log.Fatal(http.ListenAndServe(":8081", nil))
}

func askLlamaHandler(w http.ResponseWriter, r *http.Request) {
	var prompt string

	if r.Method == http.MethodPost {
		// Handle POST: read body
		body, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "Failed to read body", http.StatusBadRequest)
			return
		}
		var req map[string]string
		if err := json.Unmarshal(body, &req); err != nil {
			http.Error(w, "Invalid JSON", http.StatusBadRequest)
			return
		}
		prompt = req["prompt"]
		fmt.Printf("- payload data for prompt  %s:", prompt)
	} else if r.Method == http.MethodGet {
		// Handle GET: read from query parameter
		prompt = r.URL.Query().Get("prompt")
	} else {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if prompt == "" {
		http.Error(w, "Missing prompt", http.StatusBadRequest)
		return
	}

	response, err := Ask(prompt)
	if err != nil {
		http.Error(w, "LLaMA error: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	fmt.Printf("\n\n\n ---- Response from LLAMA :  ----\n %s:", response)
	fmt.Printf("\n ")
	json.NewEncoder(w).Encode(map[string]string{"response": response})
	//json.NewEncoder(w).Encode(response)
}

//run lllama locally with
//ollama run llama3

func Ask(prompt string) (string, error) {

	newdata := map[string]interface{}{
		"model":  "llama3.2",
		"prompt": prompt,
		"stream": false,
	}
	newjsonData, _ := json.Marshal(newdata)
	//	fmt.Printf("\n data sent to LLM server- %s", newjsonData)
	resp, err := http.Post("http://localhost:11434/api/generate", "application/json", bytes.NewBuffer(newjsonData))

	if err != nil {
		return "", err
	}
	if resp.StatusCode != http.StatusOK {
		fmt.Printf("Error: received non-OK response: %d", resp.StatusCode)
	}

	defer resp.Body.Close()

	body, _ := ioutil.ReadAll(resp.Body)

	//	fmt.Printf("\n result from LLM server- %s", body)

	var result struct {
		Response string `json:"response"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return "", fmt.Errorf("failed to parse JSON response: %w", err)
	}

	//Call Hugging Face API to generate the summary of the response

	summary := getSummaryFromHF(result.Response)
	fmt.Println("\n\n\n ==========Summarization result from Hugging Face Summary API call  :======\n", summary)
	fmt.Println("\n\n\n")
	return result.Response, nil

}

//Call Hugging Face API to generate the summary of the response

func getSummaryFromHF(text string) string {
	apiURL := "https://api-inference.huggingface.co/models/facebook/bart-large-cnn"
	hfToken := "Bearer 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"

	requestData := HFRequest{
		Inputs:    text,
		MinLength: 100,
		MaxLength: 1000, // You can tune this based on how long you want
	}

	jsonData, _ := json.Marshal(requestData)

	req, _ := http.NewRequest("POST", apiURL, bytes.NewBuffer(jsonData))
	req.Header.Set("Authorization", hfToken)
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("Failed to call HF API:", err)
		return ""
	}
	defer resp.Body.Close()

	body, _ := ioutil.ReadAll(resp.Body)

	var result HFResponse
	if err := json.Unmarshal(body, &result); err != nil || len(result) == 0 {
		fmt.Println("Summarization failed:", err)
		return string(body) // Fallback raw output
	}
	//	fmt.Println("Summarization result from Hugging Face Summary API call :", result[0].SummaryText)
	return result[0].SummaryText
}

//End call of Hugging Face API to generate the summary of the response

func main() {

	// Start HTTP server in a goroutine
	go startHTTPServer()

	lis, err := net.Listen("tcp", ":9090")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	pb.RegisterReleaseServiceServer(grpcServer, &server{})

	log.Println("Server is running on :9090")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}

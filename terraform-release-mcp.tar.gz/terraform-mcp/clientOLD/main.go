package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"google.golang.org/grpc"

	pb "terraform-mcp/mcp"
)

func main() {
	conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure())
	if err != nil {
		log.Fatal(err)
	}
	defer conn.Close()

	client := pb.NewReleaseServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	// Get Latest Release
	latest, err := client.GetLatestRelease(ctx, &pb.Empty{})
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Latest Release: %s (%s)\n", latest.Version, latest.Date)

	// Get Highlights
	highlights, err := client.GetHighlights(ctx, &pb.VersionRequest{Version: latest.Version})
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Highlights for %s:\n", latest.Version)
	for _, note := range highlights.Notes {
		fmt.Println("-", note)
	}
}
